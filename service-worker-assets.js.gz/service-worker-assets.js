self.assetsManifest = {
  "version": "ky6Ozjse",
  "assets": [
    {
      "hash": "sha256-cjtg+V4DVskeoBfufs8WNy2K9OgeAZn7YcXDWHZPAic=",
      "url": "Pages/Index.razor.js"
    },
    {
      "hash": "sha256-k01RIT/GzPFFfxopykY52A/wNOISHoMxRGyMHIHCwb4=",
      "url": "Pages/ThemeSettings.razor.js"
    },
    {
      "hash": "sha256-QvCCFl6K/4qvQj2ljOMpW85vJwz4sJm38D3cznkAeCI=",
      "url": "UI.styles.css"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-em7H1x6ijv/Ln1xS18rdjLu1JRbd3KqLfbEg9v+9Ot8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-YXK/HpBHSdAvYKGx6FxD4KNnfqJyfeRndjuw0HB6lAM=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-Ev4Kojt6pIRpgo1en7WTdMnGAI6m6iD4kfsPNHe5dzE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-PP/sd+/TmUOGcOlWecN29U8NiuDIEWAdn05aDunSL8Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-3+jF/yOfwYyQhLujhQlSrvp3NBll+oEUF7v13pin53A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-2bhET+uXWbAao2aJyUqqscx9PObMTXmpUAkDQOQBGI8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-nIU5FWzn1UKAWh1+g35w3aDIn8pSmnmQV1YWZ+1eb8w=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-C/YKywsVlWaSpZ1PLDeRKkkkM6ki2G2gT9ny+WVuERA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-5Xro3i41QLeYkA4vXMC3sJ/GOerzbXq4CJRFnA+jYNE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-EnvcMggAdstebmtcZrEOhDW5p/e0dFj2ZywJtuMypIw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-s8i9htPaAt7ZBCd4Nd0wqrNPZB5+37bPZH72pf5wd9o=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.dwk6czdzfo.bundle.scp.css"
    },
    {
      "hash": "sha256-/LPTy2KpNBBYdj9b6lNMDILfmbdqo+FWKCFS6WQd0mU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-4SNdvLM7SDhaju7Ir+uYFq6/+6PwZqn7sQPCIe+nI0g=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-kX+9ky61TMxar94Z7+S8myontpvgH4571DVehjxVvM4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-rN9ebccf1yzi+bWyyip51JJuAKONWUHDBKWnKUpDWAA=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.lib.module.js"
    },
    {
      "hash": "sha256-LdIFvKzEm8HagX4b1VAPR7Uo/BEliBDtCeCgeXTUa9s=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-9j4iJEwca5bjLN0jWGV0/0hXXIig9zItgbG2WbVWRE0=",
      "url": "_framework/Blazored.LocalStorage.aspas9o5sr.wasm"
    },
    {
      "hash": "sha256-KI0R4sbXO6WpEnDR8y3ZACSz8l0JZ5+Th/E9wGFs430=",
      "url": "_framework/FluentAssertions.sjthra2ptd.wasm"
    },
    {
      "hash": "sha256-gw5JhyVA+lyWsgfz+sEIeV4Xw5ZvIqFJdv/d/sEPV1o=",
      "url": "_framework/Microsoft.AspNetCore.Components.958tjsk8qu.wasm"
    },
    {
      "hash": "sha256-XXXGFcM+xxWNTlBns9PPuvrsSQzrGnHFJ+dS466iHUk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.vhae2zrsel.wasm"
    },
    {
      "hash": "sha256-8xNNgm8SYfD7ShAM5lUqujOtWMs/2CpiuMFi/dGPymM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.l23etm5d7f.wasm"
    },
    {
      "hash": "sha256-KaZhBimIUBGFpisb6G/c9WbXhLnMm+hMiDBS0EvJqPI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.7oj5jloqoo.wasm"
    },
    {
      "hash": "sha256-lK4oeP6+A+mfobBdI0or8qKAhjhDXnOU4b6hcT9UYUY=",
      "url": "_framework/Microsoft.CSharp.otcy0jjm1f.wasm"
    },
    {
      "hash": "sha256-+AOBWABucqvIbXvM5o13N9MMw86pSdZXhJK0nhizA64=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.crj00u2plu.wasm"
    },
    {
      "hash": "sha256-966vLTPPdM/VT3Us1DmiVRZ01ty1KKep+/sMLMGfkto=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.9oiuvi1mc3.wasm"
    },
    {
      "hash": "sha256-GEC2SjmtyS3vzBqlQUxSU4AW6gM5Tu4eipcK092PQGg=",
      "url": "_framework/Microsoft.Extensions.Configuration.sv70kdrgo7.wasm"
    },
    {
      "hash": "sha256-2HJ9N8AFtg9V92z4l+p5niLe2LalYTonUJu/vXBlT2Q=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.kdjvr1qzir.wasm"
    },
    {
      "hash": "sha256-Dld5NGeXnx7HHX1bbmTE2swyRFRwS2K5z4EujQ7P/tU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.i4pfk2iy2o.wasm"
    },
    {
      "hash": "sha256-ZDzGMj+t5VWQFakJP9dYMQFIvHJNrNjpAx/knKrvprI=",
      "url": "_framework/Microsoft.Extensions.Logging.0nqf7im5hq.wasm"
    },
    {
      "hash": "sha256-EiXPRgRn4F44pHTPJVUPyzL86kn89XefiP5NdmICxqg=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.utq95k44ap.wasm"
    },
    {
      "hash": "sha256-7RJ/wKs4xgM84vkiCdm82ynNxCIlcGRZ1nAaYcVhNtw=",
      "url": "_framework/Microsoft.Extensions.Options.9l7mrik2mr.wasm"
    },
    {
      "hash": "sha256-m4uKnWSZP3dtCWsXIeS3Pm/+yVoSU391HrlGUZo9QWM=",
      "url": "_framework/Microsoft.Extensions.Primitives.zatx90lqto.wasm"
    },
    {
      "hash": "sha256-oQSVX+j5cwTWj0OfEEE2DUJNAYxItVk7mUTNcVJttDs=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.Icons.bt83wjemql.wasm"
    },
    {
      "hash": "sha256-GIKSgfHrWBUnQtBj+XbYOq8EbZlufiZHy41i7USi9wM=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.o00w2q998x.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-njULh9eeKEWmYORJaFSJTS5lZpWQ2l4OAOw+d8h7XFg=",
      "url": "_framework/Microsoft.JSInterop.ykf6i1s2y1.wasm"
    },
    {
      "hash": "sha256-IbmwySkivXeNFNwRBnGBNta/UC+syNMmRqrxkCgTBOY=",
      "url": "_framework/Models.7eadtxfqnx.wasm"
    },
    {
      "hash": "sha256-dofphMubV0l1oNih+xiZv2dhrTu61+bcw3RIclbVhD0=",
      "url": "_framework/Newtonsoft.Json.q76kvjkd82.wasm"
    },
    {
      "hash": "sha256-QLoPyK4Hy/MiiAflkCYdNOuIQEJAUe5IicigNyXzuJw=",
      "url": "_framework/Persistence.43pdimtj32.wasm"
    },
    {
      "hash": "sha256-idEeHvY/QPf2U8C4TGUdZAgbb9FNhKW8ux4e8Ngi8ro=",
      "url": "_framework/System.Collections.7cgjx1zbrx.wasm"
    },
    {
      "hash": "sha256-fiH/yRziKMrAgxFlsrmuAhLLAFpqwgT7NlZE/W1InN4=",
      "url": "_framework/System.Collections.Concurrent.i8lk21h5xn.wasm"
    },
    {
      "hash": "sha256-6j4KrbeDX2UWMD7tk3EUkKhiezpWYx0sCOv/NB5keiY=",
      "url": "_framework/System.Collections.Immutable.ur8y23ndnh.wasm"
    },
    {
      "hash": "sha256-aujzVF6FD9FDkpUkENrGcU/wfYZqSNm1k7MnuxkwMhQ=",
      "url": "_framework/System.Collections.NonGeneric.asvq50y63e.wasm"
    },
    {
      "hash": "sha256-prK2Y8HCkNdk3omqG/S+TC3a80VCd+wJKm5RopgyL4M=",
      "url": "_framework/System.Collections.Specialized.ajzjcnvp9g.wasm"
    },
    {
      "hash": "sha256-Sf89cIcxCqRBGjY2VvN00cgeDZ2D7YeNDUINTQZ5vXY=",
      "url": "_framework/System.ComponentModel.Primitives.9009vixqeb.wasm"
    },
    {
      "hash": "sha256-JpbW3N5V09NsEG4pqCYvSbeJMk3RTxm2vj4rrxGEY9c=",
      "url": "_framework/System.ComponentModel.TypeConverter.ydnnwcr9zu.wasm"
    },
    {
      "hash": "sha256-0wCDhFo1RGmuf3YWBYJ21Nh0rakAJtW3AWRcEMocMUI=",
      "url": "_framework/System.ComponentModel.lmwos6xzya.wasm"
    },
    {
      "hash": "sha256-CUypzd26l6YQjr1s+vQUWe1QvPJ//mx25IFZh0bYN28=",
      "url": "_framework/System.Configuration.ConfigurationManager.huswae3maj.wasm"
    },
    {
      "hash": "sha256-vI2l3G+XROu4R5t4kF6ayTVe5nmEcOCoIugUzT7llpU=",
      "url": "_framework/System.Console.8zdeo72el9.wasm"
    },
    {
      "hash": "sha256-aQ1sKyZXj6IkBjuRJWnyLAENJJIFLHqmHhW+Q8lFbsk=",
      "url": "_framework/System.Data.Common.xainlb10lu.wasm"
    },
    {
      "hash": "sha256-02/9NtBxQGfejDYSOnuHfkh/FnarhDvQNEAlUqR9fo0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.xbguqyso1b.wasm"
    },
    {
      "hash": "sha256-EMIZRvRf9UX/gjTxXf+QvtzMtx1XD47haijGwM03o9g=",
      "url": "_framework/System.Diagnostics.StackTrace.cdthn2l6xl.wasm"
    },
    {
      "hash": "sha256-H85hOZtP/rmcPkk3OpqVml+Zlb6IUSmTVw3ZJ1breL8=",
      "url": "_framework/System.Diagnostics.TraceSource.t51omgoe2b.wasm"
    },
    {
      "hash": "sha256-Mw6tqQ8U2Ms5rw5alV41nE3yvrhiKj9n/JycGem1uPM=",
      "url": "_framework/System.Drawing.Primitives.ri55r6lplo.wasm"
    },
    {
      "hash": "sha256-Ej5CbdGQVpcK2/j+cvjvK5FkC46u1cBZCZyOxmX97SI=",
      "url": "_framework/System.Drawing.uta1xg9fwj.wasm"
    },
    {
      "hash": "sha256-kr+B4HX7260oCV7MAoOEkK5Jj6zD5ya0eF4tat8uJHU=",
      "url": "_framework/System.IO.Pipelines.qesjh6u5p3.wasm"
    },
    {
      "hash": "sha256-8SxfIcJSaLcFYUyvdfQ99Qm5y1VT/1KcnkXppRzcCZA=",
      "url": "_framework/System.Linq.Expressions.x487s7r58n.wasm"
    },
    {
      "hash": "sha256-fgstRNi+qZKosw0PGpE9cK1AKGo2kFNd0q7rDMEWcqw=",
      "url": "_framework/System.Linq.e9rmpaunwr.wasm"
    },
    {
      "hash": "sha256-G2XKG6dwWm8QqYW3YX9LLaGvb6ndL9Wu8Gtvfqj+KV0=",
      "url": "_framework/System.Memory.jmnqvb2rhu.wasm"
    },
    {
      "hash": "sha256-dWGoLIcQr1ZVSerbA6PE32qIGJZW7jm7QDoiEOsCe6k=",
      "url": "_framework/System.Net.Http.hp2nghw0bj.wasm"
    },
    {
      "hash": "sha256-3uKZQJT6hBGIkCtxcAw3n1Iwvd9Bfe92lNHyvOwh6ZI=",
      "url": "_framework/System.Net.Primitives.6jng6j5s8h.wasm"
    },
    {
      "hash": "sha256-rSR4TqZTt2kjjUPOmFZS2pVMiyXpBKY1E9VyOPx/Ef0=",
      "url": "_framework/System.Net.WebClient.ply2xqubf5.wasm"
    },
    {
      "hash": "sha256-tp+kdEEUstbG7AEOnuUxOmebyVf4akiRRGA123DwkXo=",
      "url": "_framework/System.ObjectModel.mdqjkg8we9.wasm"
    },
    {
      "hash": "sha256-LBq+KzDMmp9pmmiv+kuhtuZCjNePp+yIXYpnYqK/rDg=",
      "url": "_framework/System.Private.CoreLib.4ymsfe9bsh.wasm"
    },
    {
      "hash": "sha256-jnTH77byks/2BpGb5xiyLb0xmzJ0b3hKt284cvIuowg=",
      "url": "_framework/System.Private.DataContractSerialization.ywh3yj8kvw.wasm"
    },
    {
      "hash": "sha256-p1RBgfqBuM3XeB8sTAbGJJdSYq2y24PdbDL/qo9wtdM=",
      "url": "_framework/System.Private.Uri.1emga3ujoi.wasm"
    },
    {
      "hash": "sha256-B6a+Jfmj3fNWwwWEturSVrtrUzX+ByyT6i9roD0r02k=",
      "url": "_framework/System.Private.Xml.Linq.355stwqx5r.wasm"
    },
    {
      "hash": "sha256-JMELPNWfX4rZ8zmxiEpl/BFTwoAyHx+wIAxXrlWeUxU=",
      "url": "_framework/System.Private.Xml.s8ye2mkwz1.wasm"
    },
    {
      "hash": "sha256-3snP6kZEPFvzlZrM17f9mWDm1qY59hWPl0ihr9gbevk=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.iovnqz7c4y.wasm"
    },
    {
      "hash": "sha256-33EXf4KMiSgMegI0Ba3RYQByERIDBpAA5OgSCt8krZI=",
      "url": "_framework/System.Reflection.Emit.Lightweight.rxa2if2nvl.wasm"
    },
    {
      "hash": "sha256-2dV9S55cS+mv2Kd99hDd8lzWYmydkerhSvxZ2ZyRnjA=",
      "url": "_framework/System.Reflection.Primitives.rz67b88q3o.wasm"
    },
    {
      "hash": "sha256-na5qCuuSUmul34E6IJ5mSsMCIWap15kdAIr1pSkSSzs=",
      "url": "_framework/System.Runtime.7n6ngkrdea.wasm"
    },
    {
      "hash": "sha256-mCeEnV+s7uih9ScHdixDnueOK/k+dNtcpSQ9B4BW1V8=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.06941s83e9.wasm"
    },
    {
      "hash": "sha256-Q3xi1hkcWu+v5IA0vRLs3EsMHy0/+2r6unn6IhpioGs=",
      "url": "_framework/System.Runtime.InteropServices.l2yt6zkj6a.wasm"
    },
    {
      "hash": "sha256-7mJzneokxVqWslzLM3NsnF/jjgclXx3ge3r8sQ0oPlU=",
      "url": "_framework/System.Runtime.Numerics.6f3b3t0hxc.wasm"
    },
    {
      "hash": "sha256-u88q+cgQDUYghFkqP5+TwFre9iPPv0DuT4JVJh8NlcU=",
      "url": "_framework/System.Runtime.Serialization.Formatters.zuabs6tio2.wasm"
    },
    {
      "hash": "sha256-JmLgOyKLLFaLe0HZT7AMYxY7TYK9pnayuECx7KOtFCQ=",
      "url": "_framework/System.Runtime.Serialization.Primitives.akgwe1tl78.wasm"
    },
    {
      "hash": "sha256-b3LiwdfgpfxJM4rXPNjxR6sB4VQs9a5jWPX88GfWsxs=",
      "url": "_framework/System.Runtime.Serialization.Xml.jjb43zxgtr.wasm"
    },
    {
      "hash": "sha256-NWkpAbtH3XJ6cSr1MdhU9079JWtIkgPznwsc1S7TfKk=",
      "url": "_framework/System.Security.Cryptography.93gfymv8oc.wasm"
    },
    {
      "hash": "sha256-A0+dH38KcJd6RU6/cC9JWpkICkMQTow4tbf6GHHcipk=",
      "url": "_framework/System.Security.Cryptography.ProtectedData.f1t8awcip5.wasm"
    },
    {
      "hash": "sha256-JlxHKarOmy6WMiu2nr+aS/4guWuYkL7H9PvZb+BwmOE=",
      "url": "_framework/System.Text.Encoding.Extensions.a01f18beup.wasm"
    },
    {
      "hash": "sha256-G8RdLUwPCQzSBYM1GRsAX01ALeenCHZ8nvvox1TB/U8=",
      "url": "_framework/System.Text.Encodings.Web.5s3bozxz3q.wasm"
    },
    {
      "hash": "sha256-P1PYwzg7cpxDbfNf/ERWbwAYnD6nn6UC6jFudD6PJFQ=",
      "url": "_framework/System.Text.Json.v4hm38tuqf.wasm"
    },
    {
      "hash": "sha256-vbFWI7ASDmDgqSkkZyzgPYq3HpFAdSX9hw3XIKjZu9I=",
      "url": "_framework/System.Text.RegularExpressions.r61df6gf5d.wasm"
    },
    {
      "hash": "sha256-5++yr+E0o4fKb3KBevXqD4o2JP7GGF5Yq6y2Fe1GkSQ=",
      "url": "_framework/System.Threading.xyvhons7nt.wasm"
    },
    {
      "hash": "sha256-JuEj9dfBl39fqnbzXBS6GXngjNI7jj2ZEY6HaVcdW4U=",
      "url": "_framework/System.Xml.Linq.mglmvb8jto.wasm"
    },
    {
      "hash": "sha256-/ry9ZDFVJO6xqySAp51PvxeCWJCiujFjNFaMuydo7nA=",
      "url": "_framework/System.Xml.ReaderWriter.qyu9uwecoc.wasm"
    },
    {
      "hash": "sha256-wm78cmVWNkRxaGYF5J2yg5jbuR1qk/2XVrpGxxsjdHA=",
      "url": "_framework/System.Xml.XDocument.iol40e38de.wasm"
    },
    {
      "hash": "sha256-ZF5bzJ/oImlGUicP20kBlaliqXtpwj+9Mg8b9k69a60=",
      "url": "_framework/System.Xml.XmlSerializer.ci9p20i03d.wasm"
    },
    {
      "hash": "sha256-jdi196RMQvJqOZVnwRK7DGSWJifChhgNljcOjGeHSUY=",
      "url": "_framework/System.t8xd33e5pv.wasm"
    },
    {
      "hash": "sha256-NvfSCDkdamHapL2jeOgKVWlJOYFLNoDzRA8/D9JmvVU=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.yubrgxeypw.wasm"
    },
    {
      "hash": "sha256-KQD6lGx3ExonH8TCvWLry3vIHMtS6nCPMWGv0vpiEqg=",
      "url": "_framework/UI.9wu7svrt94.wasm"
    },
    {
      "hash": "sha256-/qemz8gvFpD9F/fa+CQCosOb7MnLfFeR5ORBUsZWC1s=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-wYjSscllRgsaXH0VUEf8zSZw/5lACwcJOUm+1THG5bk=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-GIlCEtISXzbsx7MiLvfuLvXYYUrRo7QpfH3dHF8iICk=",
      "url": "_framework/dotnet.native.g2xqppl9n7.wasm"
    },
    {
      "hash": "sha256-8sYhmLwY/Ns7mzp9uP6nX56olzyHkmpAL+Sf+n9gFpM=",
      "url": "_framework/dotnet.native.qum1p1g1mk.js"
    },
    {
      "hash": "sha256-Isv/63htfX73xgn3/2cZMtk4S8xBcbmlXRgJMDv4mhI=",
      "url": "_framework/dotnet.runtime.ew19f13umk.js"
    },
    {
      "hash": "sha256-aoJlb3GgiZXuVDIwfod16qWjzpVJ/Y6Z29Z4HLQlFpk=",
      "url": "_framework/netstandard.m8qrslndeu.wasm"
    },
    {
      "hash": "sha256-I0GanVsE4tKDf/vX5H+ohgCyslhvRIPf8OyuxGggd44=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-oUpLdS+SoLJFwf4bzA3iKD7TCm66oLkTpAQlVJ2s1wc=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-5XgqLa3pTOVkRieSrZyG258m8YzfpdKd4/OC/Npy0OQ=",
      "url": "data/blades-in-the-dark.json"
    },
    {
      "hash": "sha256-caFgpKU6XHS2Aajwz0Nb8FM2C0zGLrS+a8aFalXKgwo=",
      "url": "data/demo-character.json"
    },
    {
      "hash": "sha256-17G4wJYOcGsdo1S9UujWBVzwUZPO85YcldSiXqV5bdQ=",
      "url": "data/français-blades-in-the-dark.json"
    },
    {
      "hash": "sha256-0Jx8C6y3SRq6sfLKEugiA4vwC7ikVZnVeDJ9ri/e/yU=",
      "url": "data/game-settings-schema.json"
    },
    {
      "hash": "sha256-nvxkF2F9kBtXcOaPwMBXMDNK4BtEwnd9pRm5KUHT/D0=",
      "url": "data/games.json"
    },
    {
      "hash": "sha256-FS5EYVxl5uMEWHPk1XP8TH0KHYDyccE0MSVQWzINBVs=",
      "url": "data/rus-blades-in-the-dark.json"
    },
    {
      "hash": "sha256-WPohlQI1rB7kH+/7mcVibSBVNie1UNI2oMg8Fmrm3xI=",
      "url": "data/scum-and-villainy.json"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-TQdSzRqxBK3kRj5lCW8T8H7dDsHoiD9WF++ijDJjMKk=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-73fH3ihnUgzvOwjyOyy8q3HzZaKOz6733WLwIkp7Gls=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-J+uCGaI1cGx3ORmxJRajBtHwDWTDtpMIWH905Fg8y38=",
      "url": "index.html"
    },
    {
      "hash": "sha256-GwIfAZvOjaiOOUXuWK4zJsG1533rUehoB3hUsGn7jQw=",
      "url": "manifest.webmanifest"
    }
  ]
};
