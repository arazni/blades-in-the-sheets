self.assetsManifest = {
  "version": "bchGkiZ8",
  "assets": [
    {
      "hash": "sha256-cjtg+V4DVskeoBfufs8WNy2K9OgeAZn7YcXDWHZPAic=",
      "url": "Pages/Index.razor.js"
    },
    {
      "hash": "sha256-k01RIT/GzPFFfxopykY52A/wNOISHoMxRGyMHIHCwb4=",
      "url": "Pages/ThemeSettings.razor.js"
    },
    {
      "hash": "sha256-QvCCFl6K/4qvQj2ljOMpW85vJwz4sJm38D3cznkAeCI=",
      "url": "UI.styles.css"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-em7H1x6ijv/Ln1xS18rdjLu1JRbd3KqLfbEg9v+9Ot8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-YXK/HpBHSdAvYKGx6FxD4KNnfqJyfeRndjuw0HB6lAM=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-Ev4Kojt6pIRpgo1en7WTdMnGAI6m6iD4kfsPNHe5dzE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-PP/sd+/TmUOGcOlWecN29U8NiuDIEWAdn05aDunSL8Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-3+jF/yOfwYyQhLujhQlSrvp3NBll+oEUF7v13pin53A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-2bhET+uXWbAao2aJyUqqscx9PObMTXmpUAkDQOQBGI8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-nIU5FWzn1UKAWh1+g35w3aDIn8pSmnmQV1YWZ+1eb8w=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-C/YKywsVlWaSpZ1PLDeRKkkkM6ki2G2gT9ny+WVuERA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-5Xro3i41QLeYkA4vXMC3sJ/GOerzbXq4CJRFnA+jYNE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-EnvcMggAdstebmtcZrEOhDW5p/e0dFj2ZywJtuMypIw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-s8i9htPaAt7ZBCd4Nd0wqrNPZB5+37bPZH72pf5wd9o=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.dwk6czdzfo.bundle.scp.css"
    },
    {
      "hash": "sha256-/LPTy2KpNBBYdj9b6lNMDILfmbdqo+FWKCFS6WQd0mU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-4SNdvLM7SDhaju7Ir+uYFq6/+6PwZqn7sQPCIe+nI0g=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-kX+9ky61TMxar94Z7+S8myontpvgH4571DVehjxVvM4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-rN9ebccf1yzi+bWyyip51JJuAKONWUHDBKWnKUpDWAA=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.lib.module.js"
    },
    {
      "hash": "sha256-LdIFvKzEm8HagX4b1VAPR7Uo/BEliBDtCeCgeXTUa9s=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-9j4iJEwca5bjLN0jWGV0/0hXXIig9zItgbG2WbVWRE0=",
      "url": "_framework/Blazored.LocalStorage.aspas9o5sr.wasm"
    },
    {
      "hash": "sha256-KI0R4sbXO6WpEnDR8y3ZACSz8l0JZ5+Th/E9wGFs430=",
      "url": "_framework/FluentAssertions.sjthra2ptd.wasm"
    },
    {
      "hash": "sha256-gw5JhyVA+lyWsgfz+sEIeV4Xw5ZvIqFJdv/d/sEPV1o=",
      "url": "_framework/Microsoft.AspNetCore.Components.958tjsk8qu.wasm"
    },
    {
      "hash": "sha256-XXXGFcM+xxWNTlBns9PPuvrsSQzrGnHFJ+dS466iHUk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.vhae2zrsel.wasm"
    },
    {
      "hash": "sha256-8xNNgm8SYfD7ShAM5lUqujOtWMs/2CpiuMFi/dGPymM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.l23etm5d7f.wasm"
    },
    {
      "hash": "sha256-KaZhBimIUBGFpisb6G/c9WbXhLnMm+hMiDBS0EvJqPI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.7oj5jloqoo.wasm"
    },
    {
      "hash": "sha256-SrRXyKlfVP7YNgNiI7y+Ln8pXHo1QZqJVgJa3Z8/XeI=",
      "url": "_framework/Microsoft.CSharp.yxnyqxeda4.wasm"
    },
    {
      "hash": "sha256-+AOBWABucqvIbXvM5o13N9MMw86pSdZXhJK0nhizA64=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.crj00u2plu.wasm"
    },
    {
      "hash": "sha256-966vLTPPdM/VT3Us1DmiVRZ01ty1KKep+/sMLMGfkto=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.9oiuvi1mc3.wasm"
    },
    {
      "hash": "sha256-GEC2SjmtyS3vzBqlQUxSU4AW6gM5Tu4eipcK092PQGg=",
      "url": "_framework/Microsoft.Extensions.Configuration.sv70kdrgo7.wasm"
    },
    {
      "hash": "sha256-2HJ9N8AFtg9V92z4l+p5niLe2LalYTonUJu/vXBlT2Q=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.kdjvr1qzir.wasm"
    },
    {
      "hash": "sha256-Dld5NGeXnx7HHX1bbmTE2swyRFRwS2K5z4EujQ7P/tU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.i4pfk2iy2o.wasm"
    },
    {
      "hash": "sha256-ZDzGMj+t5VWQFakJP9dYMQFIvHJNrNjpAx/knKrvprI=",
      "url": "_framework/Microsoft.Extensions.Logging.0nqf7im5hq.wasm"
    },
    {
      "hash": "sha256-EiXPRgRn4F44pHTPJVUPyzL86kn89XefiP5NdmICxqg=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.utq95k44ap.wasm"
    },
    {
      "hash": "sha256-7RJ/wKs4xgM84vkiCdm82ynNxCIlcGRZ1nAaYcVhNtw=",
      "url": "_framework/Microsoft.Extensions.Options.9l7mrik2mr.wasm"
    },
    {
      "hash": "sha256-m4uKnWSZP3dtCWsXIeS3Pm/+yVoSU391HrlGUZo9QWM=",
      "url": "_framework/Microsoft.Extensions.Primitives.zatx90lqto.wasm"
    },
    {
      "hash": "sha256-oQSVX+j5cwTWj0OfEEE2DUJNAYxItVk7mUTNcVJttDs=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.Icons.bt83wjemql.wasm"
    },
    {
      "hash": "sha256-GIKSgfHrWBUnQtBj+XbYOq8EbZlufiZHy41i7USi9wM=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.o00w2q998x.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-njULh9eeKEWmYORJaFSJTS5lZpWQ2l4OAOw+d8h7XFg=",
      "url": "_framework/Microsoft.JSInterop.ykf6i1s2y1.wasm"
    },
    {
      "hash": "sha256-2CXtIME+bZipytTtvRRv4G0Hh1Gw0JkjOkMOv4kXWK0=",
      "url": "_framework/Models.og5ujkebis.wasm"
    },
    {
      "hash": "sha256-dofphMubV0l1oNih+xiZv2dhrTu61+bcw3RIclbVhD0=",
      "url": "_framework/Newtonsoft.Json.q76kvjkd82.wasm"
    },
    {
      "hash": "sha256-lCaqL7FLBVNC/4TeAXt/T7QPv0UN7GcBOc3dYpbz+YU=",
      "url": "_framework/Persistence.wh5vl5tzpx.wasm"
    },
    {
      "hash": "sha256-9eVQ4hogUQ5UysZEyTMnDfN4iN2OhYLdGVFDtCABIsM=",
      "url": "_framework/System.Collections.Concurrent.lcruc5wpcw.wasm"
    },
    {
      "hash": "sha256-3LTsp9+f2hvfyaEWp1OovliwPfPiUSledynczrTETWs=",
      "url": "_framework/System.Collections.Immutable.saej89v3bw.wasm"
    },
    {
      "hash": "sha256-Tu5/ZDTstCMQBjz6DrSQXVn01xhedLbYOJ9jitpa7ys=",
      "url": "_framework/System.Collections.NonGeneric.ibrct3nxny.wasm"
    },
    {
      "hash": "sha256-LZ5KqZ27OLlbQ4TDMQLX86yJUjx/+WXnklXAeMxKuUs=",
      "url": "_framework/System.Collections.Specialized.9l3w8faysw.wasm"
    },
    {
      "hash": "sha256-S9a5slV6qtVyCctYj3dXFooIZ1tTRPBelvGRVBiKbYc=",
      "url": "_framework/System.Collections.rcwenl1hxg.wasm"
    },
    {
      "hash": "sha256-m+FgfnhFDc9CASKav4/hqmXRz5CzFGlINAAgB3q9nHk=",
      "url": "_framework/System.ComponentModel.Primitives.fzagqf15te.wasm"
    },
    {
      "hash": "sha256-vTvQz5ENG6Fg6KZcjJwNLc8mopfaiy/kL0wgKqZkdfE=",
      "url": "_framework/System.ComponentModel.TypeConverter.pth2h5hyhk.wasm"
    },
    {
      "hash": "sha256-Y5KC/9S/D3WbFlY3pnldZ8TrRo7Y2fNKftiXhcSpz1M=",
      "url": "_framework/System.ComponentModel.phel5np7t8.wasm"
    },
    {
      "hash": "sha256-CUypzd26l6YQjr1s+vQUWe1QvPJ//mx25IFZh0bYN28=",
      "url": "_framework/System.Configuration.ConfigurationManager.huswae3maj.wasm"
    },
    {
      "hash": "sha256-XSvuk7bRq1xzdTG8PhbzSh6yP8I3iFMud7q/R92m2NE=",
      "url": "_framework/System.Console.xzd2c3ct78.wasm"
    },
    {
      "hash": "sha256-jdghddM6EnWLi0MzkuzV/mq2MxDi9EQzx7dA8offB5E=",
      "url": "_framework/System.Data.Common.7z4lje77ea.wasm"
    },
    {
      "hash": "sha256-mZaDY8V/8R4rdgTHNpp5aTRzIf2nZItIEF0HoUFTsKE=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.dbcl1dfasl.wasm"
    },
    {
      "hash": "sha256-BGd388ETvwK2A5V+PYQOUzLIoebbD29OQQ2wqy7w5KI=",
      "url": "_framework/System.Diagnostics.StackTrace.swei1zvyip.wasm"
    },
    {
      "hash": "sha256-OvVbITwJnSNGVhShSt12rSIp2TvN92oKQgDmPk1ZiKg=",
      "url": "_framework/System.Diagnostics.TraceSource.qwuja20906.wasm"
    },
    {
      "hash": "sha256-bzXJoRVcRnyoxOCSMreix72mWvcA5CAA0Cl7Rd89ruM=",
      "url": "_framework/System.Drawing.5ziebqy3j0.wasm"
    },
    {
      "hash": "sha256-XE/bGOe9SUOHrVtn72G8kmy6umC6C5xRZUXMtiMTz5o=",
      "url": "_framework/System.Drawing.Primitives.kw96hm7w10.wasm"
    },
    {
      "hash": "sha256-LkpOODvmKCczycATkH27nuFwMJ2q5dz9xDFjq+kYn7M=",
      "url": "_framework/System.IO.Pipelines.muy7q1acmn.wasm"
    },
    {
      "hash": "sha256-PYT7lxZhDkoHIYWjUVJhs4BZ0jFYEAjnoAmGbOnZ22E=",
      "url": "_framework/System.Linq.5mqytfzzm9.wasm"
    },
    {
      "hash": "sha256-4DbkAheapGmI7tRPvN/4XMZB+dcbFL4Xrxeldr7F4E0=",
      "url": "_framework/System.Linq.Expressions.002wn8yhwo.wasm"
    },
    {
      "hash": "sha256-AW4jJw/sKUZyv71fFqmhOgsEoOfScd6SHi4nx/IhEy8=",
      "url": "_framework/System.Memory.14vm3d3309.wasm"
    },
    {
      "hash": "sha256-lrpNzwsqtqd2FIxg5wdfEpvRXqFR4Giqv12I/hZP2dQ=",
      "url": "_framework/System.Net.Http.ildzbwyg2c.wasm"
    },
    {
      "hash": "sha256-vKbS2d+9a7sh2buT3NLmRitl6RSxRIbmB2eHiub1lMw=",
      "url": "_framework/System.Net.Primitives.8hda4k37jn.wasm"
    },
    {
      "hash": "sha256-jGnWImEwVQETHbzMk7tHcvgMo0RIvjFKPhVJdDDmUxw=",
      "url": "_framework/System.Net.WebClient.wn7ragcj5o.wasm"
    },
    {
      "hash": "sha256-aoux2Z6M3bRrRz8IqeK7PWCcWR9CuFp9AvFPLh6eH5w=",
      "url": "_framework/System.ObjectModel.26tfuzchia.wasm"
    },
    {
      "hash": "sha256-6BP7DdFhjoVt+VPlDY5lj9V1mavN6L6Pfy2TnI/Topk=",
      "url": "_framework/System.Private.CoreLib.8wmc5ke9ao.wasm"
    },
    {
      "hash": "sha256-C/zDQb9ck0tdX3sA1D+VjS3b1tNELfLLn/cZNdV4u0s=",
      "url": "_framework/System.Private.DataContractSerialization.npbbwz256q.wasm"
    },
    {
      "hash": "sha256-VGc2Qycu+DzUTWt0LAcwtPYsYt7uxn1EW8eKf+7XcU8=",
      "url": "_framework/System.Private.Uri.cg2ha6p3yi.wasm"
    },
    {
      "hash": "sha256-Ai0vjA4SwYCliB/3z0cc7Nsl4FXwVVWB0ISV5etqusM=",
      "url": "_framework/System.Private.Xml.Linq.qttcln0nhw.wasm"
    },
    {
      "hash": "sha256-pU2DtBhS98su40eTwEVI9QIm8ZGnX6x8TcX4ml2T7/M=",
      "url": "_framework/System.Private.Xml.l8f2caqkvs.wasm"
    },
    {
      "hash": "sha256-X+bxsI5Y61pv3d/kxPfm7VSTlVFYeprafaMqZylXxBM=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.7u6bfk7h55.wasm"
    },
    {
      "hash": "sha256-1+CsVf/BsARNP6Om55z6e9V3cOkOSi6bZ6m/aRxoAEQ=",
      "url": "_framework/System.Reflection.Emit.Lightweight.3tsgrw7c4g.wasm"
    },
    {
      "hash": "sha256-DsbZXTIkkpkVbx9luOz3EgU80fgg7jpxlhMIMr4HFAE=",
      "url": "_framework/System.Reflection.Primitives.mqh5dcggcu.wasm"
    },
    {
      "hash": "sha256-L0i0H+fU1/GTyu1L/KI/orBazyVKuNC9QtiD3PLqylY=",
      "url": "_framework/System.Runtime.57dcuvbyi3.wasm"
    },
    {
      "hash": "sha256-EWMkq8Sv0QGUZS86CVnQFDwwgt9XluMW2zvhyD3qqnk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.b9uj1fcif8.wasm"
    },
    {
      "hash": "sha256-GKeyXIVudqyr5uxwT4H4Tk8Sn43XEy6YzgAaYHY9KmA=",
      "url": "_framework/System.Runtime.InteropServices.cbd60cqyt4.wasm"
    },
    {
      "hash": "sha256-/2HCzixU2BdpJi/k0SzJcYnKsrYQppyZ11hMcX9T9tY=",
      "url": "_framework/System.Runtime.Numerics.r9agiqhr8v.wasm"
    },
    {
      "hash": "sha256-7yriVri//FggbtYrV0FHuQ1d3CwNRlX6WKZXxTPiFzQ=",
      "url": "_framework/System.Runtime.Serialization.Formatters.zvrr9zdy3a.wasm"
    },
    {
      "hash": "sha256-s7ZZbNrsTDJuRqcVyZO0yxc+8X5ANTQNtJCQ+9CK12s=",
      "url": "_framework/System.Runtime.Serialization.Primitives.f9a7v6joq7.wasm"
    },
    {
      "hash": "sha256-W3DqhVAzLl8uWyfF5d8m1Mzu7WMELID3MnbqwC+9AoI=",
      "url": "_framework/System.Runtime.Serialization.Xml.rkvqij13ms.wasm"
    },
    {
      "hash": "sha256-A0+dH38KcJd6RU6/cC9JWpkICkMQTow4tbf6GHHcipk=",
      "url": "_framework/System.Security.Cryptography.ProtectedData.f1t8awcip5.wasm"
    },
    {
      "hash": "sha256-3NAlE9xEeK37+8K3XZh2DqjBw7aUCAPHyyBMJIVSNUk=",
      "url": "_framework/System.Security.Cryptography.k40aste0y3.wasm"
    },
    {
      "hash": "sha256-F2EnIoFynO9FTiVa0TLwVvbJ9bn+a4MGhRQpzzxOOSs=",
      "url": "_framework/System.Text.Encoding.Extensions.r3tvss3oy9.wasm"
    },
    {
      "hash": "sha256-R64fxTFiD0y6i43D+82ALelUDDUyCKp0w1HPPwQlIzU=",
      "url": "_framework/System.Text.Encodings.Web.pw20fpphr8.wasm"
    },
    {
      "hash": "sha256-YCSKheBTDxeL28WRI1OZwu4JrI1LBnzlDgL1sKgdgwo=",
      "url": "_framework/System.Text.Json.kfnob9qk64.wasm"
    },
    {
      "hash": "sha256-jxLjbsH9bgAh5O5K5LTGjpOlz6+kWUnnyj6t+8dQBrc=",
      "url": "_framework/System.Text.RegularExpressions.jrfruvl2ke.wasm"
    },
    {
      "hash": "sha256-QhwvGxL6CqeA2iiRMD23V7gvgaQJJvuOTzOv1qdQVh4=",
      "url": "_framework/System.Threading.m6touv4xep.wasm"
    },
    {
      "hash": "sha256-UgDQgumqZj6p9gp1AxxwuF7FY0ittV25c4qrMW9q7XY=",
      "url": "_framework/System.Xml.Linq.62mgoxb9g2.wasm"
    },
    {
      "hash": "sha256-tPZ9/yMf5Yd25+xamZHvqyrLjsDrR/Kpc7i5k3oCryA=",
      "url": "_framework/System.Xml.ReaderWriter.gt1ip5vhy9.wasm"
    },
    {
      "hash": "sha256-jXHocYVCS/ThppEaX8pR/Ky4h/AvzicYqHMda1gq83I=",
      "url": "_framework/System.Xml.XDocument.rq3uoqeade.wasm"
    },
    {
      "hash": "sha256-UFt9PJIfF9Cp44Nl11/hZSBC8R52F/hE1pL/Ctfkhfk=",
      "url": "_framework/System.Xml.XmlSerializer.4nnk82u3rq.wasm"
    },
    {
      "hash": "sha256-fVP2BxRRKpBA0PmBbKxmO45bXDrAXVn1GthlDclLbeU=",
      "url": "_framework/System.t4d4s3f398.wasm"
    },
    {
      "hash": "sha256-NvfSCDkdamHapL2jeOgKVWlJOYFLNoDzRA8/D9JmvVU=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.yubrgxeypw.wasm"
    },
    {
      "hash": "sha256-hVmRRKQTPKM5JVzUYfn/hwcD7iCYNzaIeLg6msJRQUI=",
      "url": "_framework/UI.pbuw411bxb.wasm"
    },
    {
      "hash": "sha256-2FXQ6d0UVBaiHyI6cmScMFc753AZiF6IOR4K4wpYojk=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-T1vT02oTgL1ZyvL5isJPjfUyEmsUizbUY23kldI8wZ4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-dirwPtMRmcv2D9XEOBXey3hrud0utaqEBxRXoqAH308=",
      "url": "_framework/dotnet.native.2qybd9ixx9.js"
    },
    {
      "hash": "sha256-+SkvSq8KDLlyfxwHwDsCy2TskM6OITh3T8AXHl+Sf5k=",
      "url": "_framework/dotnet.native.d384guallf.wasm"
    },
    {
      "hash": "sha256-6QIZYgG+ftoT9N1H1EEJeXIhD/qbKqEcnmawDskiwdI=",
      "url": "_framework/dotnet.runtime.9o45ky8ejm.js"
    },
    {
      "hash": "sha256-CvwuqgaQ75bSvHJSIl/n1NrAzOzXsL18ur0U1piP64U=",
      "url": "_framework/netstandard.a3k1gi9b67.wasm"
    },
    {
      "hash": "sha256-I0GanVsE4tKDf/vX5H+ohgCyslhvRIPf8OyuxGggd44=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-oUpLdS+SoLJFwf4bzA3iKD7TCm66oLkTpAQlVJ2s1wc=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-5XgqLa3pTOVkRieSrZyG258m8YzfpdKd4/OC/Npy0OQ=",
      "url": "data/blades-in-the-dark.json"
    },
    {
      "hash": "sha256-caFgpKU6XHS2Aajwz0Nb8FM2C0zGLrS+a8aFalXKgwo=",
      "url": "data/demo-character.json"
    },
    {
      "hash": "sha256-17G4wJYOcGsdo1S9UujWBVzwUZPO85YcldSiXqV5bdQ=",
      "url": "data/français-blades-in-the-dark.json"
    },
    {
      "hash": "sha256-0Jx8C6y3SRq6sfLKEugiA4vwC7ikVZnVeDJ9ri/e/yU=",
      "url": "data/game-settings-schema.json"
    },
    {
      "hash": "sha256-nvxkF2F9kBtXcOaPwMBXMDNK4BtEwnd9pRm5KUHT/D0=",
      "url": "data/games.json"
    },
    {
      "hash": "sha256-FS5EYVxl5uMEWHPk1XP8TH0KHYDyccE0MSVQWzINBVs=",
      "url": "data/rus-blades-in-the-dark.json"
    },
    {
      "hash": "sha256-WPohlQI1rB7kH+/7mcVibSBVNie1UNI2oMg8Fmrm3xI=",
      "url": "data/scum-and-villainy.json"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-TQdSzRqxBK3kRj5lCW8T8H7dDsHoiD9WF++ijDJjMKk=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-73fH3ihnUgzvOwjyOyy8q3HzZaKOz6733WLwIkp7Gls=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-J+uCGaI1cGx3ORmxJRajBtHwDWTDtpMIWH905Fg8y38=",
      "url": "index.html"
    },
    {
      "hash": "sha256-hNlVbzw6ME6PpVkfuKxrt7PsYmKOEaKSfGMMasuVX0k=",
      "url": "manifest.webmanifest"
    }
  ]
};
