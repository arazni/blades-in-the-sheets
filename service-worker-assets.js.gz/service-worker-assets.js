self.assetsManifest = {
  "version": "wosI9SiS",
  "assets": [
    {
      "hash": "sha256-cjtg+V4DVskeoBfufs8WNy2K9OgeAZn7YcXDWHZPAic=",
      "url": "Pages/Index.razor.js"
    },
    {
      "hash": "sha256-k01RIT/GzPFFfxopykY52A/wNOISHoMxRGyMHIHCwb4=",
      "url": "Pages/ThemeSettings.razor.js"
    },
    {
      "hash": "sha256-jtuqrRPl9fzyvQFNyAT+9rSiy2LrnH4LD4OEqvsqsGk=",
      "url": "UI.styles.css"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-3TSUe9IzjOSHGNa2Ix54cmHWEhxMfT5lWU0rFSHOyCA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-eVIO/6Jn4XBhrPxEYuoZMyoeR/3B0nIi2g+eLmfzoOU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-RRtMKgoCUAcrYnPhnEvB6ZTxWToYnajdblfvl3aVTBI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DateTime/FluentTimePicker.razor.js"
    },
    {
      "hash": "sha256-cZpvuEtd1kCEHlM6AxhN1/ycVBQCToFb61YoGQ7jm5k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-EA2+gV7KUYvlKxcD9gBrvwQCj2ABhtLast89kFNa3Ko=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Dialog/FluentDialogProvider.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-m9D6O5smUPMQWbjax0bH03XYtdI3RD5geOwhizeT+gE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-FZGwgg/Fe8ELqXyr1DYZqj8mGXrXeZmbCkwOLwf4Jws=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-UqhS6+yvd9UrhzFAffmgk2ludr5ck9udmNEHb5mvchc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-OqLCO17dCq/aFFg8O0mXN/fF4czXAd6R+vgnYjtdPwc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-23+bfaqn81VwvCVPcRdX88tfObgAWPZcQfJmx1ohZYE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-FpN8ZcuZyVhdYb+cHNB4VZ5bLM+yi3gDaTZbWsahaYE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-YXiMRc9QPIiDSy+mlSF6DtYiSYb3X+1xlsCmrMrE2IU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-s2w5uif33eV2OeQRoRzZYM1ANZXb6He68mkQ3IZw9Bc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Toolbar/FluentToolbar.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-HDFs+g5h4mN46erk66GKMGS4GaQfjhGfcxi0ikR/UNc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-KjvKactqeo0HYCL5ihTqCk41+mkzZfYc9AwyQxw5hi4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-qN3xHeWLDQOB9vmVOjZ/bmPwynu7JDbesF6k8IiE/T8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.wuc5ioiakb.bundle.scp.css"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-nAfxgNZU9YZJHIhvgTrKnZuE3e+Nm6C4aEFLwA+NTUk=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-Kfky1A8y9+ZwzlY43QWt+NQrv66OFcXP+yN4JDCOmuQ=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.9c7g4riq4n.lib.module.js"
    },
    {
      "hash": "sha256-IA/Nt4K44CJSHdd49ECdOkwXOCPXawJB84eO2A5qbyk=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-9j4iJEwca5bjLN0jWGV0/0hXXIig9zItgbG2WbVWRE0=",
      "url": "_framework/Blazored.LocalStorage.aspas9o5sr.wasm"
    },
    {
      "hash": "sha256-b+Xyt4N0WkObD/1t1cHFi8lYqO0PtJSuYec43Xq7uV8=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.xka40boq5x.wasm"
    },
    {
      "hash": "sha256-C+tAXnZHEz6/mqp+P6f4MGSQXkIgdr51pXjCBraple4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.lwm0h4qnxw.wasm"
    },
    {
      "hash": "sha256-M1z0gu2YVbd0Znd0xlhH3/oWLavzCguSFXekWlCIjsc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.3oxbhr62ig.wasm"
    },
    {
      "hash": "sha256-DgQlA4lKIvm9CWdm/V0MBAo6FJrN7b9ZXOtWMXCiY18=",
      "url": "_framework/Microsoft.AspNetCore.Components.ygxmtz0ke1.wasm"
    },
    {
      "hash": "sha256-PYnPZ4IIAvS24qOPwDQco8MmZBQZVlPBbC1CWANkqGY=",
      "url": "_framework/Microsoft.CSharp.7rjz06hpjs.wasm"
    },
    {
      "hash": "sha256-vDD312Hh/i4FVWgbpeXVkVNLXAQchg678oWDTk9vuJU=",
      "url": "_framework/Microsoft.Extensions.Configuration.89zpu5iuw5.wasm"
    },
    {
      "hash": "sha256-HdU4Dp2jhxlIYprzHKCegBr7/d25wJzlxf6K0FXL7EQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.xfifq81lo7.wasm"
    },
    {
      "hash": "sha256-gSUwUNGpKWY8HWSPLR0xqMfTUMjEio3PANkGa0Vslk4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.h0zhyq1tzu.wasm"
    },
    {
      "hash": "sha256-Mhriuv1ik2VyS1lo1ALNIY/ydG5zwWgMd24PcRu7duA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.aq8wqzyl1c.wasm"
    },
    {
      "hash": "sha256-h+miBfnzud/NXWDhAau/QAtU+LZ76F4RYZhdDat3pfs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.tfs6dp9itj.wasm"
    },
    {
      "hash": "sha256-eaXO9MbympDbbVb4FaaKmjNq1uHOkaeh1YxuALA/7tU=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3x62ntw3hg.wasm"
    },
    {
      "hash": "sha256-8vYw/JT2uclfvhWYpa43DIaRhMTw7/h7AOTpzALSXAA=",
      "url": "_framework/Microsoft.Extensions.Logging.mbhxhg7j7r.wasm"
    },
    {
      "hash": "sha256-vp7UsHa6eo30C92io4j1FFc9O4VZ7/qhPhAGtQzvUtc=",
      "url": "_framework/Microsoft.Extensions.Options.2w81admykb.wasm"
    },
    {
      "hash": "sha256-I/G3J4MtF7tPH9kHhzvLtu9Hw0K3dYW1P4zFC4P3eHw=",
      "url": "_framework/Microsoft.Extensions.Primitives.r2w7f148h2.wasm"
    },
    {
      "hash": "sha256-q8FPwyLCD3cFHwyixmQ2kCG09YsiVSF5/4QuDjTQn8E=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.Icons.Filled.3mhuphjd9h.wasm"
    },
    {
      "hash": "sha256-AwNrGTWe5zQrnT4Qh1eKi2fTiATkY8TCnhRRf55v4bw=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.Icons.Regular.343pzhkokf.wasm"
    },
    {
      "hash": "sha256-Ak+inVmdB000NwhogydNJBFFJrhYaU51Tet3QJd2sBo=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.qyiol9u8pe.wasm"
    },
    {
      "hash": "sha256-QV1viS0CpfSMRAZMqC3d4gn29mwLre1E0MFyjak27W8=",
      "url": "_framework/Microsoft.JSInterop.7atiewr52m.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-zkLwSR782TrRxVFWG7f9K3xs9d4J0U/q7+Z4XuSZppE=",
      "url": "_framework/Models.u5ytntyhqf.wasm"
    },
    {
      "hash": "sha256-feprp68G4fjzgl8foBviyM7L09pKFutDzpqksES4xIE=",
      "url": "_framework/Newtonsoft.Json.7nwps67rq0.wasm"
    },
    {
      "hash": "sha256-wTBAB9lKR6Kuj4yGAkyabblvGPzE6dkhSPTw8QuIqgE=",
      "url": "_framework/Persistence.niyis9b1ho.wasm"
    },
    {
      "hash": "sha256-KmUXiZE65Byy9e2ya0FhUXwJVEnMgGWtrm7Gxdam0U8=",
      "url": "_framework/System.Collections.6ovas4vvgz.wasm"
    },
    {
      "hash": "sha256-b1tMleSVUg0P5xFcZet3D2eZXtqAUeUObj6/6GZXVsc=",
      "url": "_framework/System.Collections.Concurrent.b9etm603xe.wasm"
    },
    {
      "hash": "sha256-bMoR3i6GgrNZ7UU6GQrbL23xQsBdl5bJVvm5C26jvSk=",
      "url": "_framework/System.Collections.Immutable.w3ijg29o7k.wasm"
    },
    {
      "hash": "sha256-TSimfIJ4on2SexXaza2oURJH5NpRCduOORdaCg9JxYw=",
      "url": "_framework/System.Collections.NonGeneric.ftpovkv4ds.wasm"
    },
    {
      "hash": "sha256-b6DFyNBvFb0b21ZPvIIJrgVrwWWdpyFIpmAs7FWS++U=",
      "url": "_framework/System.Collections.Specialized.rd0q0b1k63.wasm"
    },
    {
      "hash": "sha256-hD+E+PlhugfAQxapLnf50hopB9r0db37eB1K2jLyNYw=",
      "url": "_framework/System.ComponentModel.0bzvssvmpm.wasm"
    },
    {
      "hash": "sha256-BD7cVE6hapylpWsjzILEWOlN6elPOBXVa4Clp8LstsY=",
      "url": "_framework/System.ComponentModel.Primitives.c07mxlg7up.wasm"
    },
    {
      "hash": "sha256-2YLe0+hpkufU/Tmu07cJk7ogs6gcVi11JYLZYq+psHE=",
      "url": "_framework/System.ComponentModel.TypeConverter.ns2sspa157.wasm"
    },
    {
      "hash": "sha256-mv8gUrD213Wds8c0h+q0B8qmYiAA6e+yoH5d2SKUMFA=",
      "url": "_framework/System.Console.ajr0tu4vu1.wasm"
    },
    {
      "hash": "sha256-gQTGl20/BvQZvDYzL1ouHt4TmyvbLgPHnOrfHjqdtn4=",
      "url": "_framework/System.Data.Common.hoxkxvkpy3.wasm"
    },
    {
      "hash": "sha256-DI0CGvVrkRv6m1ET3iVrcBayF61f0P08jKCe4k51zpg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0x97ls63f0.wasm"
    },
    {
      "hash": "sha256-C9XBulpiX71jBXPv9LP8mLmgTP7r63xEmO+YCxv4f9c=",
      "url": "_framework/System.Diagnostics.TraceSource.vbeqiuwq6u.wasm"
    },
    {
      "hash": "sha256-kaM48Tu+Xa/yYCPPj7ts6khJuSzveJimFSSt66ut2tw=",
      "url": "_framework/System.Drawing.Primitives.zfby2rabp8.wasm"
    },
    {
      "hash": "sha256-ExiEXldajSXRA8hlBB/dgLKQ8pUu3C1XHu9Fk/8tAWk=",
      "url": "_framework/System.Drawing.hzrl70oes7.wasm"
    },
    {
      "hash": "sha256-4V8y/r8mIQUqThfSlQtQb1OWscKbzKdi2Z9Tqirxgbg=",
      "url": "_framework/System.IO.Pipelines.lv7oyoqbmg.wasm"
    },
    {
      "hash": "sha256-v9+mxqmE8hWCuVeUHfjZPKneRXg1Tcg55Y+w9XZyhjs=",
      "url": "_framework/System.Linq.AsyncEnumerable.5ve8bynksj.wasm"
    },
    {
      "hash": "sha256-xdm530l6C3DnMSMgFlcOISYoJiFnvMw08TVIow5DrC0=",
      "url": "_framework/System.Linq.Expressions.jun25jrl0i.wasm"
    },
    {
      "hash": "sha256-jbdZ7rbhYun+fxdAlK/C10wGZmXVbMAOW6XeqrxN+8s=",
      "url": "_framework/System.Linq.nv4z9vopn2.wasm"
    },
    {
      "hash": "sha256-LMk6yYHYCE76YQj/ZHsxMnJfOmtVRGGM3SHehaVucqk=",
      "url": "_framework/System.Memory.sad2vehc1e.wasm"
    },
    {
      "hash": "sha256-SbJTngJPRZuYlUnzep+w9E5EgFhpKGd0tPIfFBnZK/E=",
      "url": "_framework/System.Net.Http.fyew65wl5d.wasm"
    },
    {
      "hash": "sha256-RR0jUgsrFWtiXSRt9FCligGi0KR9wwBZXOUOXkKpO60=",
      "url": "_framework/System.Net.Primitives.lcsfs1agtm.wasm"
    },
    {
      "hash": "sha256-RS9wCaSKvW5ak4x9yE+TgwtPwoXgRGmVZg5fBr6pixs=",
      "url": "_framework/System.ObjectModel.pbaw73egrl.wasm"
    },
    {
      "hash": "sha256-x/WBPHgG/poJbKM3PxRwgnbRtPFsqxiG8lPhdkgpymk=",
      "url": "_framework/System.Private.CoreLib.f2fix2dgi6.wasm"
    },
    {
      "hash": "sha256-mzqODtjhP4ld/NiC0Crkrdiv2rgJP6VrKStMMYTThNk=",
      "url": "_framework/System.Private.Uri.bs6huo0na8.wasm"
    },
    {
      "hash": "sha256-TnB08A2RWenq3I39nipIbHho9Nfu4U1eF6x353VqQSY=",
      "url": "_framework/System.Private.Xml.Linq.y87kyrkp1l.wasm"
    },
    {
      "hash": "sha256-lTukZn12VqQ7e0Fp6FeOiQv9taLfo+jSMLUj/ixvfso=",
      "url": "_framework/System.Private.Xml.l8ylbgbbmu.wasm"
    },
    {
      "hash": "sha256-A9ba1VreAAocoKO6j+9hh3dVYZdtiRdGmom3f0vRVeQ=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.nrq2i87ca2.wasm"
    },
    {
      "hash": "sha256-5wONtRvzLYH+2AEUKTMK9vbupQ52hNbMaTq6xRS+RJg=",
      "url": "_framework/System.Reflection.Emit.Lightweight.drgpnljn6u.wasm"
    },
    {
      "hash": "sha256-eOKVSmRg2DCmYv7jDXNtAubRk8D+1SxMRSdnfL+vtkc=",
      "url": "_framework/System.Reflection.Primitives.ow7qzw33ie.wasm"
    },
    {
      "hash": "sha256-vKg//NU9oZPi14Tb+kFvHFPz4jFrULcNa8kX2bNbRmY=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.44f7zr85b4.wasm"
    },
    {
      "hash": "sha256-4985d1OuSFoiZM828vxbFM3kv9n5HIcxWGRBeUqK5vQ=",
      "url": "_framework/System.Runtime.InteropServices.nfjmsewd4m.wasm"
    },
    {
      "hash": "sha256-k5mvBvLTP+15FUok7BpZs+QQYrOW5wp0CY4gBhYcV2A=",
      "url": "_framework/System.Runtime.Numerics.bi007cokqz.wasm"
    },
    {
      "hash": "sha256-6rOkljW6YtnpgNS+VBiaPZr/IoV2xBhwS9nRRr9Xvn8=",
      "url": "_framework/System.Runtime.Serialization.Formatters.emjju9katl.wasm"
    },
    {
      "hash": "sha256-uGw6JTwiWu4JrSAidUvLxx/TUJDTSIaq/TLMmYpk9C8=",
      "url": "_framework/System.Runtime.Serialization.Primitives.wy9hkzm7y2.wasm"
    },
    {
      "hash": "sha256-+eFZB/y4IMRP1C589ateRXRojqDp76dFptgnVPofiG8=",
      "url": "_framework/System.Runtime.h2aoxee4i6.wasm"
    },
    {
      "hash": "sha256-gAwXYdZH4esGIFjQvULfjmzMXZ9AVQ8zAFEyeRqBNIQ=",
      "url": "_framework/System.Security.Cryptography.oe7co9khw6.wasm"
    },
    {
      "hash": "sha256-icUeuZMJ7bSqg5lpKE0/fvS0zok96n4VkCXCE8+69yU=",
      "url": "_framework/System.Text.Encoding.Extensions.n02huyrv2q.wasm"
    },
    {
      "hash": "sha256-YfFYvjnoBM5syjRpW8jntvM64YdwzlrwHdlo73h8lyk=",
      "url": "_framework/System.Text.Encodings.Web.t9wcrexjbf.wasm"
    },
    {
      "hash": "sha256-rCs6rdIJFaPZ+knBOb+1RukFGA2dtShX91udg7awe4M=",
      "url": "_framework/System.Text.Json.ozlofszj03.wasm"
    },
    {
      "hash": "sha256-vJMxGG4dY+POcTzzflfhjHUOp1SA+RdtDIP1w/c2BQ8=",
      "url": "_framework/System.Text.RegularExpressions.whgjaickf0.wasm"
    },
    {
      "hash": "sha256-zK89OTeij+l5iQhgvHeI4nHScEGstaeMxn0JwnAWKF4=",
      "url": "_framework/System.Threading.k6q9j4k0wa.wasm"
    },
    {
      "hash": "sha256-SadbI6GYTXw7kHrIi4GlY7FN4lwLNLpROb7GWs6KOFM=",
      "url": "_framework/System.Xml.Linq.l1dhntk8qt.wasm"
    },
    {
      "hash": "sha256-dCxLvxMXLa+EoQqmJm5hGvJUscIlK0Wps3/g3cTYf+s=",
      "url": "_framework/System.Xml.ReaderWriter.ccdgo9pvou.wasm"
    },
    {
      "hash": "sha256-pYTIZgWXFHXO9yPvuydUD6HqmkEWfVEDUT0tEFysuoQ=",
      "url": "_framework/System.Xml.XDocument.jmr66ttqxz.wasm"
    },
    {
      "hash": "sha256-Sd3s9Vn4Uscsky7aa9pkHZrTKzPZT0ckLQ5cMvbAis0=",
      "url": "_framework/System.l5g27qddaj.wasm"
    },
    {
      "hash": "sha256-8KAkneOn7oZgpiOrJX7Q5aL+K9OxuVKXjCKqvoHBnb0=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.oqvl9xwt8q.wasm"
    },
    {
      "hash": "sha256-zcRRhRbTqANxSavr++KQBxJcwU0hndaqKV5pv7vJDGg=",
      "url": "_framework/UI.d042gdukn5.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-8FjquroHMnH1pyo1GD7g+K40GtqDDQrL268ALutiZQM=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-Fdqj8gXL3vAj6jAMhYhlRsUirlYTTMT+3OWEC0aCOA0=",
      "url": "_framework/dotnet.native.509ygenkdu.js"
    },
    {
      "hash": "sha256-b1/fYCMHJITCwq516g276r0PjkXYoqntljyvEBpBzLw=",
      "url": "_framework/dotnet.native.hombpk5ivu.wasm"
    },
    {
      "hash": "sha256-yJvgPPUUvavYVmu9VD/fYtMcoEnLVaB0Cr7JAE29btw=",
      "url": "_framework/dotnet.runtime.o0qy896u8v.js"
    },
    {
      "hash": "sha256-I0GanVsE4tKDf/vX5H+ohgCyslhvRIPf8OyuxGggd44=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-oUpLdS+SoLJFwf4bzA3iKD7TCm66oLkTpAQlVJ2s1wc=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-5XgqLa3pTOVkRieSrZyG258m8YzfpdKd4/OC/Npy0OQ=",
      "url": "data/blades-in-the-dark.json"
    },
    {
      "hash": "sha256-caFgpKU6XHS2Aajwz0Nb8FM2C0zGLrS+a8aFalXKgwo=",
      "url": "data/demo-character.json"
    },
    {
      "hash": "sha256-17G4wJYOcGsdo1S9UujWBVzwUZPO85YcldSiXqV5bdQ=",
      "url": "data/français-blades-in-the-dark.json"
    },
    {
      "hash": "sha256-0Jx8C6y3SRq6sfLKEugiA4vwC7ikVZnVeDJ9ri/e/yU=",
      "url": "data/game-settings-schema.json"
    },
    {
      "hash": "sha256-nvxkF2F9kBtXcOaPwMBXMDNK4BtEwnd9pRm5KUHT/D0=",
      "url": "data/games.json"
    },
    {
      "hash": "sha256-FS5EYVxl5uMEWHPk1XP8TH0KHYDyccE0MSVQWzINBVs=",
      "url": "data/rus-blades-in-the-dark.json"
    },
    {
      "hash": "sha256-WPohlQI1rB7kH+/7mcVibSBVNie1UNI2oMg8Fmrm3xI=",
      "url": "data/scum-and-villainy.json"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-TQdSzRqxBK3kRj5lCW8T8H7dDsHoiD9WF++ijDJjMKk=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-73fH3ihnUgzvOwjyOyy8q3HzZaKOz6733WLwIkp7Gls=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-tXvTkIn0qUKxYnoydspJ4wCTGnhZn7ufkMJyyiAs6Ho=",
      "url": "index.html"
    },
    {
      "hash": "sha256-1A1k9nzxmk7DEHBnJUd7mUc5YAWsy0SeMArg2bZUgX4=",
      "url": "manifest.webmanifest"
    }
  ]
};
