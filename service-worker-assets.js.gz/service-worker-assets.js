self.assetsManifest = {
  "version": "17RAhIpo",
  "assets": [
    {
      "hash": "sha256-cjtg+V4DVskeoBfufs8WNy2K9OgeAZn7YcXDWHZPAic=",
      "url": "Pages/Index.razor.js"
    },
    {
      "hash": "sha256-k01RIT/GzPFFfxopykY52A/wNOISHoMxRGyMHIHCwb4=",
      "url": "Pages/ThemeSettings.razor.js"
    },
    {
      "hash": "sha256-QvCCFl6K/4qvQj2ljOMpW85vJwz4sJm38D3cznkAeCI=",
      "url": "UI.styles.css"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-em7H1x6ijv/Ln1xS18rdjLu1JRbd3KqLfbEg9v+9Ot8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-YXK/HpBHSdAvYKGx6FxD4KNnfqJyfeRndjuw0HB6lAM=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-Ev4Kojt6pIRpgo1en7WTdMnGAI6m6iD4kfsPNHe5dzE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-PP/sd+/TmUOGcOlWecN29U8NiuDIEWAdn05aDunSL8Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-3+jF/yOfwYyQhLujhQlSrvp3NBll+oEUF7v13pin53A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-2bhET+uXWbAao2aJyUqqscx9PObMTXmpUAkDQOQBGI8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-nIU5FWzn1UKAWh1+g35w3aDIn8pSmnmQV1YWZ+1eb8w=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-C/YKywsVlWaSpZ1PLDeRKkkkM6ki2G2gT9ny+WVuERA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-5Xro3i41QLeYkA4vXMC3sJ/GOerzbXq4CJRFnA+jYNE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-EnvcMggAdstebmtcZrEOhDW5p/e0dFj2ZywJtuMypIw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-s8i9htPaAt7ZBCd4Nd0wqrNPZB5+37bPZH72pf5wd9o=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.dwk6czdzfo.bundle.scp.css"
    },
    {
      "hash": "sha256-/LPTy2KpNBBYdj9b6lNMDILfmbdqo+FWKCFS6WQd0mU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-4SNdvLM7SDhaju7Ir+uYFq6/+6PwZqn7sQPCIe+nI0g=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-kX+9ky61TMxar94Z7+S8myontpvgH4571DVehjxVvM4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-rN9ebccf1yzi+bWyyip51JJuAKONWUHDBKWnKUpDWAA=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.lib.module.js"
    },
    {
      "hash": "sha256-LdIFvKzEm8HagX4b1VAPR7Uo/BEliBDtCeCgeXTUa9s=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-9j4iJEwca5bjLN0jWGV0/0hXXIig9zItgbG2WbVWRE0=",
      "url": "_framework/Blazored.LocalStorage.aspas9o5sr.wasm"
    },
    {
      "hash": "sha256-KI0R4sbXO6WpEnDR8y3ZACSz8l0JZ5+Th/E9wGFs430=",
      "url": "_framework/FluentAssertions.sjthra2ptd.wasm"
    },
    {
      "hash": "sha256-gw5JhyVA+lyWsgfz+sEIeV4Xw5ZvIqFJdv/d/sEPV1o=",
      "url": "_framework/Microsoft.AspNetCore.Components.958tjsk8qu.wasm"
    },
    {
      "hash": "sha256-XXXGFcM+xxWNTlBns9PPuvrsSQzrGnHFJ+dS466iHUk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.vhae2zrsel.wasm"
    },
    {
      "hash": "sha256-8xNNgm8SYfD7ShAM5lUqujOtWMs/2CpiuMFi/dGPymM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.l23etm5d7f.wasm"
    },
    {
      "hash": "sha256-IIcyKKCtpjmG1LFF8qtNDVqV8eJ3w3Wsmw8BGR9AQx8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.w82mof53lb.wasm"
    },
    {
      "hash": "sha256-oILZo59AKTIIcP7XBVfKllfdAcdnQ5A9XeMImdTsZ7M=",
      "url": "_framework/Microsoft.CSharp.8uqftgxfyp.wasm"
    },
    {
      "hash": "sha256-+AOBWABucqvIbXvM5o13N9MMw86pSdZXhJK0nhizA64=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.crj00u2plu.wasm"
    },
    {
      "hash": "sha256-966vLTPPdM/VT3Us1DmiVRZ01ty1KKep+/sMLMGfkto=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.9oiuvi1mc3.wasm"
    },
    {
      "hash": "sha256-GEC2SjmtyS3vzBqlQUxSU4AW6gM5Tu4eipcK092PQGg=",
      "url": "_framework/Microsoft.Extensions.Configuration.sv70kdrgo7.wasm"
    },
    {
      "hash": "sha256-2HJ9N8AFtg9V92z4l+p5niLe2LalYTonUJu/vXBlT2Q=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.kdjvr1qzir.wasm"
    },
    {
      "hash": "sha256-Dld5NGeXnx7HHX1bbmTE2swyRFRwS2K5z4EujQ7P/tU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.i4pfk2iy2o.wasm"
    },
    {
      "hash": "sha256-ZDzGMj+t5VWQFakJP9dYMQFIvHJNrNjpAx/knKrvprI=",
      "url": "_framework/Microsoft.Extensions.Logging.0nqf7im5hq.wasm"
    },
    {
      "hash": "sha256-EiXPRgRn4F44pHTPJVUPyzL86kn89XefiP5NdmICxqg=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.utq95k44ap.wasm"
    },
    {
      "hash": "sha256-7RJ/wKs4xgM84vkiCdm82ynNxCIlcGRZ1nAaYcVhNtw=",
      "url": "_framework/Microsoft.Extensions.Options.9l7mrik2mr.wasm"
    },
    {
      "hash": "sha256-m4uKnWSZP3dtCWsXIeS3Pm/+yVoSU391HrlGUZo9QWM=",
      "url": "_framework/Microsoft.Extensions.Primitives.zatx90lqto.wasm"
    },
    {
      "hash": "sha256-oQSVX+j5cwTWj0OfEEE2DUJNAYxItVk7mUTNcVJttDs=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.Icons.bt83wjemql.wasm"
    },
    {
      "hash": "sha256-GIKSgfHrWBUnQtBj+XbYOq8EbZlufiZHy41i7USi9wM=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.o00w2q998x.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-njULh9eeKEWmYORJaFSJTS5lZpWQ2l4OAOw+d8h7XFg=",
      "url": "_framework/Microsoft.JSInterop.ykf6i1s2y1.wasm"
    },
    {
      "hash": "sha256-usFpOfYmvRmDc735qHFeeGYZokFcwiwPG1hhxoRsFNg=",
      "url": "_framework/Models.y5bb9q2zmf.wasm"
    },
    {
      "hash": "sha256-dofphMubV0l1oNih+xiZv2dhrTu61+bcw3RIclbVhD0=",
      "url": "_framework/Newtonsoft.Json.q76kvjkd82.wasm"
    },
    {
      "hash": "sha256-KEVUPG7jKMAZIRzKm+XM/1P41fAtp4Q6n49ruLIX4OU=",
      "url": "_framework/Persistence.g68fqto4kx.wasm"
    },
    {
      "hash": "sha256-nmhUPBjB8ZbEN0U5j2acgnW4fkbSYlov7U3e30Lsp8A=",
      "url": "_framework/System.6bp5k9v1ih.wasm"
    },
    {
      "hash": "sha256-crr3cv9ku5fAqEGM6fmd0THoAPi3vvlxwlvvyyfR/Kc=",
      "url": "_framework/System.Collections.Concurrent.6uxthdrlri.wasm"
    },
    {
      "hash": "sha256-lJH6XWSkr+kZZ5O82ffH1LsuKo4ZhYue8/L1jYcaqIo=",
      "url": "_framework/System.Collections.Immutable.s6acv9ltuc.wasm"
    },
    {
      "hash": "sha256-UagLQH4ZXfqNhSkJyBowCrKla7CTJHoT7/vOCypgWGs=",
      "url": "_framework/System.Collections.NonGeneric.btlxrol3ai.wasm"
    },
    {
      "hash": "sha256-vfsUIxmunFysZy1bOebqVMQ0XKmrhDo1/CEAhnlXO7s=",
      "url": "_framework/System.Collections.Specialized.f1ddljmjfh.wasm"
    },
    {
      "hash": "sha256-FXlcuZLPnrEFHLfDLYYoAvl1xoPPDHpU010wrPEuc60=",
      "url": "_framework/System.Collections.tucs984x6l.wasm"
    },
    {
      "hash": "sha256-ha7EMWf4VygJSWNugminB5GRxseAiZ5/81PrEM7gpec=",
      "url": "_framework/System.ComponentModel.1lh6stivdm.wasm"
    },
    {
      "hash": "sha256-/YLM4LEYkjuEJLAt7nqLadod7IHtGgSnVVDuHs2c7u8=",
      "url": "_framework/System.ComponentModel.Primitives.be4joy04o9.wasm"
    },
    {
      "hash": "sha256-phiKU/zOchEY4Wwmo46vugOGUfQCtGa9qpt5zu/5rL0=",
      "url": "_framework/System.ComponentModel.TypeConverter.ypclhtyii8.wasm"
    },
    {
      "hash": "sha256-CUypzd26l6YQjr1s+vQUWe1QvPJ//mx25IFZh0bYN28=",
      "url": "_framework/System.Configuration.ConfigurationManager.huswae3maj.wasm"
    },
    {
      "hash": "sha256-EaIqp1369JDugdkV4iLQwteKwmZi7ow2y4EPf2ZFtvY=",
      "url": "_framework/System.Console.rp9vfrqve4.wasm"
    },
    {
      "hash": "sha256-ros3w75vZz92bYzruZf0viGCC9nBCG/9Z29EVEcFrug=",
      "url": "_framework/System.Data.Common.e0urfr0s1l.wasm"
    },
    {
      "hash": "sha256-PRXdH+yc+rku/ntBgyx5EQuHAKQP3FlrLUwSRTAubOw=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.d42mh4exua.wasm"
    },
    {
      "hash": "sha256-qAIsDuLvULJwfrUVf5EsAAOh86VfMUDaN9d5hSrCtHY=",
      "url": "_framework/System.Diagnostics.StackTrace.gari0a8jxz.wasm"
    },
    {
      "hash": "sha256-0nUC8vfDJ0O+d8xlYHqzoPn85zj6zkUjB2fiS0u4u08=",
      "url": "_framework/System.Diagnostics.TraceSource.i3jem7u8n6.wasm"
    },
    {
      "hash": "sha256-y0g5olltgTNL2E30wEH9ERv/J5SXsKqxOB3RSCjs+Lc=",
      "url": "_framework/System.Drawing.Primitives.nxtlyfkarb.wasm"
    },
    {
      "hash": "sha256-7OYyS/EvxxJePK8hvB0aD96TeLlyptw5TWV6IDYwhc8=",
      "url": "_framework/System.Drawing.w36gg13qvp.wasm"
    },
    {
      "hash": "sha256-jJ6cfHVmmYcw0lTmR2a1TgUc8C32HZDPh2cOCA21L7E=",
      "url": "_framework/System.IO.Pipelines.wv1s2h4d36.wasm"
    },
    {
      "hash": "sha256-OJCB+SkU6sMVJdS/zmsAgmqt805q/wt/JusUFudhJ1o=",
      "url": "_framework/System.Linq.0mq2t0mced.wasm"
    },
    {
      "hash": "sha256-Z2clwgwSL7/jS0+Biisb6q+lAT6OK5Qjs17E/Hokgsk=",
      "url": "_framework/System.Linq.Expressions.5lao5efxcc.wasm"
    },
    {
      "hash": "sha256-G3Ttg9K/D8YNRGqBI1nFFQE+HL7xw6yXuLAwLfL3NAM=",
      "url": "_framework/System.Memory.jyk4piv8lk.wasm"
    },
    {
      "hash": "sha256-Os6/3XOTXzo0CakDl3fQfkU+3WQpQ7UqdTpDiN5MBOk=",
      "url": "_framework/System.Net.Http.u37pijm4up.wasm"
    },
    {
      "hash": "sha256-pw05g0BaEKVbzP4WPQea9g0RxQNbpGxbODFcox3/CjU=",
      "url": "_framework/System.Net.Primitives.n4ouc3gbqm.wasm"
    },
    {
      "hash": "sha256-sQ36PEmoUDj2fSTMCOcSrilaR6JnXOxQ1k07OkpDBLg=",
      "url": "_framework/System.Net.WebClient.3n1w2klra0.wasm"
    },
    {
      "hash": "sha256-JWzrfXA3yRzoJsgfvCV2gCHhzkb/vHWIIj6IwY6nh04=",
      "url": "_framework/System.ObjectModel.ndbdpkdfs0.wasm"
    },
    {
      "hash": "sha256-GsnKuoCbDlfwHfUfIUkChJffF/NJM84jfC48mzCGTgw=",
      "url": "_framework/System.Private.CoreLib.ytz2dia7sg.wasm"
    },
    {
      "hash": "sha256-mXG07lEsahkMPUr2ydVg1AYGo6bjTy4sOkWEyAIR7bM=",
      "url": "_framework/System.Private.DataContractSerialization.1m84x30vak.wasm"
    },
    {
      "hash": "sha256-RQ0GtqCmHIYtydMBjz5vcaedQDUbO+qnTBykfH/kflc=",
      "url": "_framework/System.Private.Uri.t2yrc3j6ro.wasm"
    },
    {
      "hash": "sha256-PvtwfZlkcqb92IikSkfA4yaGzWSaZwFIE/WkACo7/8U=",
      "url": "_framework/System.Private.Xml.Linq.6v6g6a58qq.wasm"
    },
    {
      "hash": "sha256-wM/YjKvcQlrGngzXTp+JJseJ9pEwRf7z6UuMP7Re2ts=",
      "url": "_framework/System.Private.Xml.g0bupdpwmo.wasm"
    },
    {
      "hash": "sha256-gP+HYHzPCqozAAabaDbzFh+7DJLPJ1sdH9w/d0MxzbU=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.oyya4rylr5.wasm"
    },
    {
      "hash": "sha256-5XUvHhr+USgxFvmU7VVIWmFS7fwgsd0sSnIae9pKDAM=",
      "url": "_framework/System.Reflection.Emit.Lightweight.l4ojtalmyq.wasm"
    },
    {
      "hash": "sha256-YQDKI2k1d6ATDOvjsrM7U4AN4tjTJw6nlAo/0GnC1rQ=",
      "url": "_framework/System.Reflection.Primitives.pi8p9sv67y.wasm"
    },
    {
      "hash": "sha256-a5MyBuzizPxYqdzmsikUBQL1f3kXFhYiFXTq5GoeZ/w=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.nh37mohxcm.wasm"
    },
    {
      "hash": "sha256-bgPphZZq/aazmZeKOWZO4ebAiuQtGPzLE/G+ewwfrro=",
      "url": "_framework/System.Runtime.InteropServices.udm938qejv.wasm"
    },
    {
      "hash": "sha256-SVVseOddEqiySSqa5lGsfmZfyerSoLmlZw7Z+glrWH4=",
      "url": "_framework/System.Runtime.Numerics.7otae6xtzx.wasm"
    },
    {
      "hash": "sha256-MY5UP8qPt3cLQI3o193VLI5/6yQx355y6b6aRnSrc/k=",
      "url": "_framework/System.Runtime.Serialization.Formatters.xobc0202iq.wasm"
    },
    {
      "hash": "sha256-Wb51PU2poU/WoC6t4TGdUMRECpPBFwrMdYHRwZYFMpw=",
      "url": "_framework/System.Runtime.Serialization.Primitives.z98r7ah01y.wasm"
    },
    {
      "hash": "sha256-BnoSt0+7T/1x98Jz9lXYmBDO98Loiu1eY3Ozi+vAYZQ=",
      "url": "_framework/System.Runtime.Serialization.Xml.qjglvl0ppf.wasm"
    },
    {
      "hash": "sha256-CNqgOEhcJxSIkxk+d+CMCbvVCyVXfDTTMdOI/RDFu4w=",
      "url": "_framework/System.Runtime.sfwnmrkn6k.wasm"
    },
    {
      "hash": "sha256-A0+dH38KcJd6RU6/cC9JWpkICkMQTow4tbf6GHHcipk=",
      "url": "_framework/System.Security.Cryptography.ProtectedData.f1t8awcip5.wasm"
    },
    {
      "hash": "sha256-XKwudKtgfwdC6aVZGSDtfhv6k5Lk/I49vl99KsXa2HE=",
      "url": "_framework/System.Security.Cryptography.wz97izgzgh.wasm"
    },
    {
      "hash": "sha256-FsNtnmSmX8069WLOrvOhtCUt2wU0YFzbOL9okLMg2Gw=",
      "url": "_framework/System.Text.Encoding.Extensions.yx11f5emv7.wasm"
    },
    {
      "hash": "sha256-kOPtHz0vw909+8X/9RQPEYEgugNrJJtLRPOSSjB7cbw=",
      "url": "_framework/System.Text.Encodings.Web.oq1fx3gayd.wasm"
    },
    {
      "hash": "sha256-Je+tHIU/XODOLn9GOwAEcHYjVGphuPXAiZxnEDMxQ+g=",
      "url": "_framework/System.Text.Json.r0s4m91kzn.wasm"
    },
    {
      "hash": "sha256-BJZ0O1D3w1ZF/0m/lP06QjIx/IZZ93zZWUHgoEuBdX8=",
      "url": "_framework/System.Text.RegularExpressions.sebp8upzrw.wasm"
    },
    {
      "hash": "sha256-NJsgeBNtrkugS9uVKhyjeUVgz7N/LKMwtd1A5VqF/V4=",
      "url": "_framework/System.Threading.85xcq6c58u.wasm"
    },
    {
      "hash": "sha256-50dVChh2QJYCLLia2vmYR8/Cyxw2D7Y5dFwnnzVUiZ0=",
      "url": "_framework/System.Xml.Linq.bbx5kr3gw0.wasm"
    },
    {
      "hash": "sha256-W1Tcj0Ou95FmCKnoMZhQ+KXRbVvGR+u/kaZc3n9BheY=",
      "url": "_framework/System.Xml.ReaderWriter.7xf314nl0k.wasm"
    },
    {
      "hash": "sha256-5uzroEB10mAZCZ0VTgdXoiF0kOCNX27xMjgMkPlWa/w=",
      "url": "_framework/System.Xml.XDocument.q32h0u5hry.wasm"
    },
    {
      "hash": "sha256-AE3LLKXfwsJlaLcDOqb8KGMmdlessX3O7UaFuQYVHWo=",
      "url": "_framework/System.Xml.XmlSerializer.s103ebtqit.wasm"
    },
    {
      "hash": "sha256-NvfSCDkdamHapL2jeOgKVWlJOYFLNoDzRA8/D9JmvVU=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.yubrgxeypw.wasm"
    },
    {
      "hash": "sha256-XCbP+fX8LzJ1JKSiFS/C+ro58XIBYnYeloiCp6mJLSE=",
      "url": "_framework/UI.sg8u8qbpqp.wasm"
    },
    {
      "hash": "sha256-9yt7EMtS/ik6rE5KZB1r6lQc0ro0VisOmAUhUik51rM=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-GbKWK+esqeL1E24rCVsCvsQCzaJM65aknWOT1UhUYa4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-ggBUpgkY2/Et4hgXwtFuiGgkef93z97rjN7nq5gaLYs=",
      "url": "_framework/dotnet.native.ul7wm7k2x5.wasm"
    },
    {
      "hash": "sha256-Wl+IUqcv1ipPVANeT6wNZJ/6q9g7DYs0Gt04+iBi960=",
      "url": "_framework/dotnet.native.yal6ewum71.js"
    },
    {
      "hash": "sha256-uD1t4tsPtmIHsx30SC4OztehGGaHVDksFD38rL2e3P4=",
      "url": "_framework/dotnet.runtime.o8gq1i8bk6.js"
    },
    {
      "hash": "sha256-sxvWqIY4k/YRa/FUh5qO8xR8QpQAiiB6qyHXiwm+aRM=",
      "url": "_framework/netstandard.rajwe5fkg9.wasm"
    },
    {
      "hash": "sha256-I0GanVsE4tKDf/vX5H+ohgCyslhvRIPf8OyuxGggd44=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-oUpLdS+SoLJFwf4bzA3iKD7TCm66oLkTpAQlVJ2s1wc=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-5XgqLa3pTOVkRieSrZyG258m8YzfpdKd4/OC/Npy0OQ=",
      "url": "data/blades-in-the-dark.json"
    },
    {
      "hash": "sha256-caFgpKU6XHS2Aajwz0Nb8FM2C0zGLrS+a8aFalXKgwo=",
      "url": "data/demo-character.json"
    },
    {
      "hash": "sha256-17G4wJYOcGsdo1S9UujWBVzwUZPO85YcldSiXqV5bdQ=",
      "url": "data/français-blades-in-the-dark.json"
    },
    {
      "hash": "sha256-0Jx8C6y3SRq6sfLKEugiA4vwC7ikVZnVeDJ9ri/e/yU=",
      "url": "data/game-settings-schema.json"
    },
    {
      "hash": "sha256-0zDh5z0gDesMxXbK0kRU9aEBIGb9FYLqf15z0i64Yos=",
      "url": "data/games.json"
    },
    {
      "hash": "sha256-WPohlQI1rB7kH+/7mcVibSBVNie1UNI2oMg8Fmrm3xI=",
      "url": "data/scum-and-villainy.json"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-TQdSzRqxBK3kRj5lCW8T8H7dDsHoiD9WF++ijDJjMKk=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-73fH3ihnUgzvOwjyOyy8q3HzZaKOz6733WLwIkp7Gls=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-bAkFe7dRUe0E7TliEM87qSK/vyf6kgh8mh42wQdUFr8=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fPY7NPNxjWtf3xihK+O361nL8+1zG1S5P/33wqguUTs=",
      "url": "manifest.webmanifest"
    }
  ]
};
